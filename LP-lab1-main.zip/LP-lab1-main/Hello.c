#include <stdio.h>//загрузка стандартной библиотеки языка C

void main(){
    printf("Hello, World!\n");//Вывод команды
}